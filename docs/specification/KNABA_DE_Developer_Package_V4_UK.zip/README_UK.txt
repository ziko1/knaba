KNABA DE — пакет технічного завдання V4, 08.10.2026

1. KNABA_DE_Technical_Spec_V4_UK.md — повний нормативний документ; 24 блоки вимог, 72 acceptance criteria, джерела та mapping V3.
2. KNABA_DE_Developer_Brief_V4_UK.pdf — коротка карта на 3 сторінках; не замінює повне ТЗ.
3. KNABA_DE_Acceptance_V4.csv — реєстр перевірок для розробника; усі статуси NOT_RUN. CSV у UTF-8 з BOM.
4. DOCUMENT_VALIDATION.json — перевірки узгодженості документа, не тести продукту.
5. SHA256SUMS.txt — контрольні суми файлів пакета.

Для репозиторію скопіювати повний Markdown як KNABA_DE_MASTER_SPEC.md. Створювати задачі за KNB-ID, фіксувати покриття AC-ID та фактичні evidence. Реалізація, доступи, production deploy й тести продукту в межах підготовки цього ТЗ не виконувались.
